
# This is for code for a lambda function that will be used to get all the emails from the database and return them as a response to the API Gateway.
import json
import logging
import pymysql
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DB_HOST = os.environ['DB_HOST']
DB_USER = os.environ['DB_USER']
DB_PASSWORD = os.environ['DB_PASSWORD']
DB_NAME = os.environ['DB_NAME']

def get_connection():
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

def get_one_email():
    email = event['queryStringParameters']['email']
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            sql = "SELECT member_id, member_email FROM tww_members WHERE member_email = %s"
            cursor.execute(sql, (email,))
            result = cursor.fetchone()
            if result:
                return {"id": result[0], "email": result[1]}  # Return as an object
            else:
                return None
    finally:
        connection.close()

def get_emails():
    connection = get_connection()
    try:
        with connection.cursor() as cursor:
            sql = "SELECT member_email FROM tww_members"
            cursor.execute(sql)
            result = cursor.fetchall()
            emails = [row[0] for row in result]  # Extract emails from the result
            return emails
    finally:
        connection.close()

def HandleRequest(event, context):
    logger.info("Newest Received event: %s", json.dumps(event, indent=2))
    
    user = get_one_email()
    
    data = {
        "id": user["id"] if user else None,
        "member_email": user["email"] if user else None
    }
    
    return {
        "statusCode": 200,
        "body": json.dumps(data)
    }